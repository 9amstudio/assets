<?php
/**
 * Posts not found template
 */
?>
<h3 class="nova-posts__not-found"><?php esc_html_e( 'Posts not found', 'nova-elements' ); ?></h3>
