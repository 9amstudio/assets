<?php
/**
 * Animated text list start template
 */
?>
<div class="nova-animated-text__animated-text">
