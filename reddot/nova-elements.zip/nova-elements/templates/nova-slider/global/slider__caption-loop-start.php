<?php

$settings = $this->get_settings_for_display();

?>

<div class="slider__caption swiper-container">
  <div class="swiper-wrapper">
