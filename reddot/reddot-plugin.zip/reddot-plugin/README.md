=== Reddot Addons Plugin ===
Contributors:  9amstudio, novaworks, dzungnova
Tags: gutenberg, blocks
Requires at least: 5.0
Tested up to: 5.0
Stable tag: 1.0.0
Requires PHP: 5.5.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
~Current Version:1.0.0~

The plugin for Reddot Woocommerce WordPress Theme

== Changelog ==

= 1.0.0 =
- Initial Version
